import cv2
import numpy as np
import os

'''
    Haar cascade classifier est un algorithme qui fait une classification entre les images avec un objet 
    (c'est-à-dire le visage) et les images sans objet (c'est-à-dire avec des non-visages).

    • Dans un premier temps, plusieurs centaines d'images avec visage et plusieurs centaines d'images 
    sans visage ont été confiées à ce classificateur. 
    • Ce classificateur a ensuite été formé en appliquant des méthodes d'apprentissage automatique 
    comme les réseaux de neurones pour reconnaître les visages humains. 
    • Il a ensuite extrait les caractéristiques Haar de ces images et les a stockées dans un fichier xml 
    qui est dans notre cas le fichier  haarcascade_frontalface_default.xml.

'''
face_classifier = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

def face_extractor(img):

    gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    faces = face_classifier.detectMultiScale(gray,1.3,5)
    # detectMultiScale  : cette méthode ne fonctionne que sur les images en niveaux de gris. 
    '''
    MultiScale détecte des objets de différentes tailles dans l'image d'entrée et renvoie des rectangles positionnés sur les faces. 
    Le premier argument est l'image, le second est le facteur d'échelle (de combien la taille de l'image sera réduite à chaque échelle d'image), 
    et le troisième est le minNeighbors (combien de voisins chaque rectangle devrait avoir).
    Les valeurs de 1,3 et 5 sont basées sur l'expérimentation et le choix de celles qui ont le mieux fonctionné.
    '''

    if  faces is():
        return None

    for(x,y,w,h) in faces:
        # Nous allons parcourir chaque rectangle (chaque face détectée) en utilisant ses coordonnées générées par la fonction.
        cropped_face = img[y:y+h, x:x+w]

    return cropped_face


'''
    Ici, nous accédons au caméra de notre system . Lorsque le paramètre est 0, nous accédons à une caméra interne depuis l'ordinateur.
    Lorsque le paramètre est 1, nous accédons à une caméra externe qui est branchée sur  l'ordinateur.
'''
cap = cv2.VideoCapture(0)
count = 0

nameID=str(input("Entrez votre nom : ")).lower()
path='./image/'+nameID

isExist = os.path.exists(path)

if isExist:
	print("Nom deja existant !!!")
	nameID=str(input("Essayez d'enrer un nouveau nom : "))
else:
        # on va creer un doccier sous le nom de patiant et dans lequel on sauvegard ses images ...
	os.makedirs(path)
while True:
    ret, frame = cap.read()
    # a chaque fois on le system prend une photos de visage et la sauvegarder dans le doccier qu'on vient de creer
    '''
    La méthode cv2.imwrite() est utilisée pour enregistrer une image sur n'importe quel périphérique de stockage.
    Cela enregistrera l'image selon le format spécifié dans le répertoire de travail actuel.
    '''
    if face_extractor(frame) is not None:
        count+=1
        face = cv2.resize(face_extractor(frame),(200,200))
        face = cv2.cvtColor(face, cv2.COLOR_BGR2GRAY)

        file_name_path ='./image/'+nameID+'/'+ str(count) + '.jpg'
        
        cv2.imwrite(file_name_path,face)

        cv2.putText(face,str(count),(50,50),cv2.FONT_HERSHEY_COMPLEX,1,(0,255,0),2)
        # La méthode cv2.imshow() est utilisée pour afficher une image (le visage dans notre cas) dans une fenêtre. 
        # et La fenêtre s'adapte automatiquement à la taille de l'image.
        cv2.imshow('Face Cropper',face)
    else:
        # si jamais aucun face n'est pas detecter on affich un message
        print("Face not found")
        pass
    # lorsque le nombre de photos depasse 100 on arrete la processus de detection s'arrete
    if cv2.waitKey(1)==13 or count==100:
        break

cap.release()
cv2.destroyAllWindows()